#include "VideoEventHandle.h"

VideoCallBack::~VideoCallBack()
{

}
